
# Quiz Website - SQLite Version (Codespaces Ready)

## Run
```
dotnet restore
dotnet tool install --global dotnet-ef
dotnet ef migrations add init
dotnet ef database update
dotnet run
```

## Login
admin / admin
