
using Microsoft.EntityFrameworkCore;
using QuizSQLite.Models;

namespace QuizSQLite.Data {
    public class AppDb:DbContext{
        public AppDb(DbContextOptions<AppDb> o):base(o){}
        public DbSet<User> Users => Set<User>();
        public DbSet<Exam> Exams => Set<Exam>();
        public DbSet<Question> Questions => Set<Question>();
        public DbSet<Choice> Choices => Set<Choice>();
        public DbSet<Result> Results => Set<Result>();
        public DbSet<Answer> Answers => Set<Answer>();
    }
}
