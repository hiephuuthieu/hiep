
using Microsoft.AspNetCore.Mvc;
using QuizSQLite.Data;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace QuizSQLite.Controllers{
    public class AccountController:Controller{
        private readonly AppDb _db;
        public AccountController(AppDb db){_db=db;}
        public IActionResult Login()=>View();
        [HttpPost]
        public IActionResult Login(string username,string password){
            var u=_db.Users.FirstOrDefault(x=>x.Username==username && x.Password==password);
            if(u==null){ViewBag.Err="Wrong"; return View();}
            HttpContext.Session.SetInt32("uid",u.Id);
            HttpContext.Session.SetString("role",u.Role);
            return RedirectToAction("Index","Home");
        }
        public IActionResult Logout(){HttpContext.Session.Clear(); return RedirectToAction("Index","Home");}
    }
}
