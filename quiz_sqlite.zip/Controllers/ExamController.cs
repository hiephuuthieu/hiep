
using Microsoft.AspNetCore.Mvc;
using QuizSQLite.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace QuizSQLite.Controllers{
 public class ExamController:Controller{
   private readonly AppDb _db;
   public ExamController(AppDb db){_db=db;}

   public IActionResult List()=>View(_db.Exams.ToList());

   public IActionResult Start(int id){
        var q=_db.Questions.Where(x=>x.ExamId==id).ToList();
        HttpContext.Session.SetString("qids", string.Join(",", q.Select(x=>x.Id)));
        HttpContext.Session.SetInt32("exam", id);
        return View("Take", q);
   }

   [HttpPost]
   public IActionResult Submit(){
        var qids = HttpContext.Session.GetString("qids")?.Split(',').Select(int.Parse).ToList();
        int examId = HttpContext.Session.GetInt32("exam") ?? 0;
        int uid = HttpContext.Session.GetInt32("uid") ?? 0;
        int correct=0;
        foreach(var q in qids){
            if(int.TryParse(Request.Form[$"q_{q}"], out int c)){
                var ch=_db.Choices.Find(c);
                if(ch!=null && ch.IsCorrect) correct++;
            }
        }
        var r=new QuizSQLite.Models.Result{ExamId=examId,UserId=uid,Score=correct,TakenAt=DateTime.Now};
        _db.Results.Add(r); _db.SaveChanges();
        return RedirectToAction("Result", new{id=r.Id});
   }

   public IActionResult Result(int id)=>View(_db.Results.Find(id));
 }
}
